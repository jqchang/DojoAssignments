//
//  ViewController.swift
//  cold_call_v1
//
//  Created by Justin Chang on 3/7/17.
//  Copyright © 2017 Justin Chang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var names = ["Uyanga", "Courtney", "Bryant", "Jimmy", "Ryota", "Cody", "Jay"]
    var nameIndex = 0;
    @IBOutlet weak var nameLabel: UILabel!
    @IBAction func callButtonPressed(_ sender: Any) {
        nameIndex = Int(arc4random_uniform(UInt32(names.count)))
        updateUI()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func updateUI() {
        nameLabel.text = names[nameIndex]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


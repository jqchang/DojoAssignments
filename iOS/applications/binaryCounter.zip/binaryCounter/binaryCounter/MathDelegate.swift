//
//  MathDelegate.swift
//  binaryCounter
//
//  Created by Justin Chang on 3/20/17.
//  Copyright © 2017 Justin Chang. All rights reserved.
//

import UIKit

protocol MathDelegate: class {
    func buttonWasPressed(value: Int)
}

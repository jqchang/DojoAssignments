//
//  EditTarget.swift
//  bucketlist_fromscratch
//
//  Created by Justin Chang on 3/20/17.
//  Copyright © 2017 Justin Chang. All rights reserved.
//

import Foundation

struct editTarget {
    var targetIndex:Int
    var targetStr:String
}

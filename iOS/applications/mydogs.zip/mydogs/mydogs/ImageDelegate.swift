//
//  ImageDelegate.swift
//  mydogs
//
//  Created by Justin Chang on 3/23/17.
//  Copyright © 2017 Justin Chang. All rights reserved.
//

import Foundation
import UIKit

protocol ImageDelegate:class {
    func imagePicked(image:UIImage?)
}

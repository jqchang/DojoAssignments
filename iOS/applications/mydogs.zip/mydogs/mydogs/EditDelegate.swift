//
//  EditDelegate.swift
//  mydogs
//
//  Created by Justin Chang on 3/21/17.
//  Copyright © 2017 Justin Chang. All rights reserved.
//

import Foundation

protocol EditDelegate: class {
    func editButtonPressed(sender: DogCell)
}

//
//  AddDelegate.swift
//  todolist
//
//  Created by Justin Chang on 3/21/17.
//  Copyright © 2017 Justin Chang. All rights reserved.
//

protocol AddDelegate: class {
    func addButtonPressed()
}

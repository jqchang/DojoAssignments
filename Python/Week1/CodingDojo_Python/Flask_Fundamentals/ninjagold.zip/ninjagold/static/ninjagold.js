$(document).ready(function(){
  $('.log').scrollTop($('.log')[0].scrollHeight);
});
